import { motion } from "motion/react";

interface PeterRevealProps {
  onComplete: () => void;
}

export function PeterReveal({ onComplete }: PeterRevealProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="w-full h-full flex items-center justify-center relative"
      style={{
        background: "linear-gradient(135deg, rgba(255, 255, 255, 1) 0%, rgba(243, 244, 246, 0.5) 100%)"
      }}
    >
      <div className="flex flex-col items-center">
        {/* Peter Avatar */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="relative mb-6"
        >
          <div
            className="absolute inset-0 rounded-full blur-3xl opacity-30"
            style={{
              background: "radial-gradient(circle, rgba(147, 197, 253, 0.6) 0%, transparent 70%)",
            }}
          />
          <div className="relative w-48 h-48 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-2xl">
            <div className="text-8xl">🤖</div>
          </div>
        </motion.div>

        {/* Speech Card */}
        <motion.div
          initial={{ y: 12, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="bg-white rounded-3xl px-8 py-6 shadow-lg max-w-md"
          style={{
            boxShadow: "0 10px 40px rgba(0, 0, 0, 0.1)",
          }}
        >
          <p className="text-lg text-gray-800">
            Hi! I'm <span className="font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Peter</span>.
            <br />
            What do you want to work on today?
          </p>
        </motion.div>

        {/* Continue button */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          onClick={onComplete}
          className="mt-8 px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transition-shadow"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Start with Peter
        </motion.button>
      </div>
    </motion.div>
  );
}
