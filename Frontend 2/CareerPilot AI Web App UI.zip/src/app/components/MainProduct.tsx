import { motion } from "motion/react";
import { useState } from "react";
import { Send, Sparkles, TrendingUp, BookOpen, Target } from "lucide-react";

export function MainProduct() {
  const [message, setMessage] = useState("");

  const messages = [
    { type: "ai", text: "Hi! I'm Peter, your AI career companion. How can I help you today?" },
    { type: "user", text: "I want to improve my resume for a senior developer role" },
    { type: "ai", text: "Great! I can help you craft a compelling resume. Let's start by highlighting your key achievements and technical skills." },
  ];

  return (
    <div className="w-full min-h-screen" style={{
      background: "linear-gradient(135deg, #ffffff 0%, #f0f9ff 50%, #fce7f3 100%)"
    }}>
      <div className="max-w-[1440px] mx-auto px-20 py-16">
        {/* Main 2-Column Layout */}
        <div className="grid grid-cols-12 gap-8 mb-24">
          {/* Left Column */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="col-span-7 flex flex-col justify-center"
          >
            {/* Logo */}
            <div className="mb-6">
              <div className="text-xs tracking-[0.2em] text-gray-500 mb-2">AI CAREER COMPANION</div>
              <h1
                className="text-7xl font-bold mb-0"
                style={{
                  background: "linear-gradient(135deg, #3b82f6 0%, #8b5cf6 50%, #06b6d4 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  filter: "drop-shadow(0 4px 12px rgba(59, 130, 246, 0.3))",
                }}
              >
                CareerPilot
              </h1>
            </div>

            {/* Heading */}
            <h2 className="text-6xl font-bold text-gray-900 mb-4 leading-tight">
              Your AI Career Companion
            </h2>

            {/* Subtext */}
            <p className="text-lg text-gray-600 mb-8">
              Navigate your career journey with AI-powered guidance, personalized advice, and expert insights.
            </p>

            {/* CTAs */}
            <div className="flex gap-4 mb-8">
              <button className="px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all">
                Start with Peter
              </button>
              <button className="px-8 py-4 border-2 border-gray-300 text-gray-700 rounded-2xl hover:border-gray-400 transition-all">
                View Features
              </button>
            </div>

            {/* Stats */}
            <div className="flex gap-6 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <span className="text-2xl">✓</span>
                <span>50K+ Users</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">✓</span>
                <span>98% Interview Rate</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-2xl">✓</span>
                <span>4.9/5 Rating</span>
              </div>
            </div>
          </motion.div>

          {/* Right Column - Chat Card */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="col-span-5"
          >
            <div
              className="bg-white rounded-3xl p-6 h-[520px] flex flex-col"
              style={{
                boxShadow: "0 20px 60px rgba(0, 0, 0, 0.1)",
              }}
            >
              {/* Chat Header */}
              <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-purple-400 flex items-center justify-center text-xl">
                  🤖
                </div>
                <div>
                  <div className="font-medium text-gray-900">Peter AI</div>
                  <div className="text-xs text-green-600 flex items-center gap-1">
                    <span className="w-2 h-2 bg-green-600 rounded-full"></span>
                    Online
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto py-4 space-y-4">
                {messages.map((msg, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.2 }}
                    className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                        msg.type === "user"
                          ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Input */}
              <div className="pt-4 border-t border-gray-200">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Ask Peter anything about your career…"
                    className="flex-1 px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 focus:outline-none focus:border-blue-400 transition-colors"
                  />
                  <button className="px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:opacity-90 transition-opacity">
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Features Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <div className="text-center mb-12">
            <h3 className="text-4xl font-bold text-gray-900 mb-3">Powerful Features</h3>
            <p className="text-lg text-gray-600">Everything you need to accelerate your career</p>
          </div>

          <div className="grid grid-cols-4 gap-6">
            {[
              {
                icon: <Sparkles className="w-8 h-8" />,
                title: "Resume Generator",
                description: "AI-powered resume creation tailored to your industry and role",
                gradient: "from-blue-500 to-cyan-500"
              },
              {
                icon: <TrendingUp className="w-8 h-8" />,
                title: "Career Suggestions",
                description: "Personalized career paths based on your skills and goals",
                gradient: "from-purple-500 to-pink-500"
              },
              {
                icon: <BookOpen className="w-8 h-8" />,
                title: "Interview Prep",
                description: "Practice with AI-generated questions and get instant feedback",
                gradient: "from-orange-500 to-red-500"
              },
              {
                icon: <Target className="w-8 h-8" />,
                title: "Skill Roadmap",
                description: "Structured learning paths to reach your career objectives",
                gradient: "from-green-500 to-emerald-500"
              },
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + idx * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="bg-white rounded-2xl p-6 cursor-pointer"
                style={{
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.08)",
                }}
              >
                <div
                  className={`w-16 h-16 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center text-white mb-4`}
                  style={{
                    boxShadow: "0 8px 16px rgba(0, 0, 0, 0.15)",
                  }}
                >
                  {feature.icon}
                </div>
                <h4 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h4>
                <p className="text-sm text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
