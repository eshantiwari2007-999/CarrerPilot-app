import { motion } from "motion/react";
import { useState } from "react";

interface IntroSectionProps {
  onComplete: () => void;
}

function StarSparkle({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path
        d="M12 2L13.2 10.8L22 12L13.2 13.2L12 22L10.8 13.2L2 12L10.8 10.8L12 2Z"
        fill="url(#sg1)"
      />
      <defs>
        <linearGradient id="sg1" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#6366f1" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function AmbientParticles() {
  const particles = [
    { x: "7%",  y: "15%", s: 3, o: 0.35, d: 0 },
    { x: "93%", y: "20%", s: 2, o: 0.3,  d: 0.6 },
    { x: "14%", y: "75%", s: 2.5, o: 0.28, d: 1.0 },
    { x: "86%", y: "70%", s: 3, o: 0.35, d: 0.9 },
    { x: "50%", y: "6%",  s: 2, o: 0.22, d: 1.5 },
    { x: "27%", y: "44%", s: 1.5, o: 0.18, d: 0.3 },
    { x: "75%", y: "52%", s: 2, o: 0.22, d: 1.3 },
    { x: "38%", y: "88%", s: 1.5, o: 0.2, d: 0.7 },
    { x: "62%", y: "90%", s: 2, o: 0.25, d: 0.2 },
  ];
  return (
    <>
      {particles.map((p, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{
            left: p.x, top: p.y,
            width: p.s, height: p.s,
            background: "radial-gradient(circle, #818cf8, #c084fc)",
            opacity: p.o,
          }}
          animate={{ opacity: [p.o, p.o * 2.2, p.o], scale: [1, 1.6, 1] }}
          transition={{ duration: 3 + i * 0.35, repeat: Infinity, delay: p.d, ease: "easeInOut" }}
        />
      ))}
    </>
  );
}

export function IntroSection({ onComplete }: IntroSectionProps) {
  const [phase, setPhase] = useState<"idle" | "connecting" | "done">("idle");
  const isConnecting = phase === "connecting" || phase === "done";

  const handleConnect = () => {
    if (phase !== "idle") return;
    setPhase("connecting");
    setTimeout(() => {
      setPhase("done");
      setTimeout(() => onComplete(), 700);
    }, 1500);
  };

  return (
    <motion.div
      className="relative w-full h-screen overflow-hidden flex flex-col items-center"
      style={{
        background:
          "linear-gradient(128deg, #cfdeff 0%, #e2e9ff 18%, #eeeaff 40%, #fce3f4 68%, #ffd8e9 88%, #ffd0e3 100%)",
        userSelect: "none",
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
    >
      <AmbientParticles />

      {/* ══════════════════════════════════════
          TOP — Brand + Headline
      ══════════════════════════════════════ */}
      <motion.div
        className="relative z-20 flex flex-col items-center"
        style={{ paddingTop: "clamp(28px, 4.5vh, 56px)" }}
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.85, ease: "easeOut", delay: 0.1 }}
      >
        {/* Logo row */}
        <div className="flex items-center gap-2 mb-2">
          <StarSparkle size={17} />
          <span
            style={{
              fontSize: "1.05rem",
              fontWeight: 600,
              letterSpacing: "-0.015em",
              color: "#1e1b4b",
            }}
          >
            CareerPilot
          </span>
        </div>

        {/* Eyebrow label */}
        <div
          style={{
            fontSize: "0.59rem",
            letterSpacing: "0.23em",
            color: "#94a3b8",
            textTransform: "uppercase",
            fontWeight: 400,
            marginBottom: "clamp(14px, 2.2vh, 24px)",
          }}
        >
          AI Career Companion
        </div>

        {/* Hero heading */}
        <h1
          style={{
            fontSize: "clamp(2rem, 4.2vw, 3.75rem)",
            fontWeight: 700,
            textAlign: "center",
            lineHeight: 1.08,
            letterSpacing: "-0.03em",
            color: "#0f172a",
            marginBottom: "clamp(8px, 1.2vh, 14px)",
          }}
        >
          Where Human Meets{" "}
          <span
            style={{
              background: "linear-gradient(118deg, #3b82f6 0%, #6366f1 42%, #8b5cf6 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 22px rgba(99,102,241,0.3))",
            }}
          >
            AI
          </span>
        </h1>

        {/* Subtext */}
        <p
          style={{
            fontSize: "clamp(0.82rem, 1vw, 0.93rem)",
            color: "#64748b",
            fontWeight: 400,
            textAlign: "center",
            letterSpacing: "0.005em",
          }}
        >
          Your intelligent career companion, powered by the future.
        </p>
      </motion.div>

      {/* ══════════════════════════════════════
          MAIN — Hands + Center Glow + Button
      ══════════════════════════════════════ */}
      <div className="relative w-full flex-1">

        {/* ── ROBOT HAND (Left) ── */}
        <div
          className="absolute"
          style={{ left: "-5%", top: "50%", width: "55%", transform: "translateY(-52%)" }}
        >
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{
              x: isConnecting ? 75 : 0,
              opacity: phase === "done" ? 0 : 1,
            }}
            transition={{
              x: { duration: 1.0, ease: [0.22, 1, 0.36, 1] },
              opacity: { duration: phase === "done" ? 0.9 : 0.9, delay: phase === "done" ? 0.45 : 0 },
            }}
          >
            <img
              src="https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=1000&q=90"
              alt="Robotic hand"
              draggable={false}
              style={{
                width: "100%",
                height: "auto",
                objectFit: "contain",
                display: "block",
                mixBlendMode: "multiply",
                filter:
                  "drop-shadow(0 4px 80px rgba(99,102,241,0.22)) brightness(1.08) contrast(1.06) saturate(0.9)",
                maskImage:
                  "linear-gradient(to right, rgba(0,0,0,0.9) 0%, rgba(0,0,0,1) 55%, rgba(0,0,0,0.2) 88%, rgba(0,0,0,0) 100%)",
                WebkitMaskImage:
                  "linear-gradient(to right, rgba(0,0,0,0.9) 0%, rgba(0,0,0,1) 55%, rgba(0,0,0,0.2) 88%, rgba(0,0,0,0) 100%)",
                transform: "rotateY(-5deg) rotateZ(1.5deg) scale(1.06)",
                transformOrigin: "right center",
              }}
            />
          </motion.div>
        </div>

        {/* ── HUMAN HAND (Right) ── */}
        <div
          className="absolute"
          style={{ right: "-5%", top: "50%", width: "55%", transform: "translateY(-52%)" }}
        >
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{
              x: isConnecting ? -75 : 0,
              opacity: phase === "done" ? 0 : 1,
            }}
            transition={{
              x: { duration: 1.0, ease: [0.22, 1, 0.36, 1] },
              opacity: { duration: phase === "done" ? 0.9 : 0.9, delay: phase === "done" ? 0.45 : 0 },
            }}
          >
            <img
              src="https://images.unsplash.com/photo-1590650153855-d9e808231d41?w=1000&q=90"
              alt="Human hand"
              draggable={false}
              style={{
                width: "100%",
                height: "auto",
                objectFit: "contain",
                display: "block",
                mixBlendMode: "multiply",
                filter:
                  "drop-shadow(0 4px 70px rgba(236,72,153,0.14)) brightness(1.04) contrast(1.02)",
                maskImage:
                  "linear-gradient(to left, rgba(0,0,0,0.9) 0%, rgba(0,0,0,1) 55%, rgba(0,0,0,0.2) 88%, rgba(0,0,0,0) 100%)",
                WebkitMaskImage:
                  "linear-gradient(to left, rgba(0,0,0,0.9) 0%, rgba(0,0,0,1) 55%, rgba(0,0,0,0.2) 88%, rgba(0,0,0,0) 100%)",
                transform: "scaleX(-1) rotateY(-5deg) rotateZ(1.5deg) scale(1.06)",
                transformOrigin: "left center",
              }}
            />
          </motion.div>
        </div>

        {/* ── CENTER: Wide soft ambient glow ── */}
        <div
          className="absolute"
          style={{ left: "50%", top: "50%", transform: "translate(-50%, -50%)", pointerEvents: "none" }}
        >
          <motion.div
            animate={{
              scale: isConnecting ? [1, 2.5, 4.5] : [1, 1.1, 1],
              opacity: isConnecting ? [0.85, 0.6, 0] : [0.5, 0.75, 0.5],
            }}
            transition={{
              duration: isConnecting ? 1.4 : 3.2,
              repeat: isConnecting ? 0 : Infinity,
              ease: "easeOut",
            }}
          >
            <div
              style={{
                width: 220,
                height: 220,
                borderRadius: "50%",
                background:
                  "radial-gradient(circle, rgba(255,255,255,0.96) 0%, rgba(193,215,255,0.65) 28%, rgba(139,92,246,0.18) 62%, transparent 85%)",
                filter: "blur(30px)",
              }}
            />
          </motion.div>
        </div>

        {/* ── CENTER: Bright fingertip core dot ── */}
        <div
          className="absolute z-10"
          style={{ left: "50%", top: "50%", transform: "translate(-50%, -50%)", pointerEvents: "none" }}
        >
          <motion.div
            animate={{
              scale: isConnecting ? [1, 5, 10] : [1, 1.35, 1],
              opacity: isConnecting ? [1, 0.7, 0] : [0.8, 1, 0.8],
            }}
            transition={{
              duration: isConnecting ? 1.2 : 2.4,
              repeat: isConnecting ? 0 : Infinity,
              ease: "easeOut",
            }}
          >
            <div
              style={{
                width: 14,
                height: 14,
                borderRadius: "50%",
                background: "radial-gradient(circle, #ffffff 0%, rgba(186,210,255,0.92) 50%, transparent 100%)",
                boxShadow:
                  "0 0 18px 8px rgba(186,210,255,0.75), 0 0 45px 18px rgba(139,92,246,0.28)",
              }}
            />
          </motion.div>
        </div>

        {/* ── CENTER: Expanding ripple rings (on connect) ── */}
        {isConnecting &&
          [0, 0.2, 0.42].map((delay, i) => (
            <div
              key={i}
              className="absolute"
              style={{
                left: "50%",
                top: "50%",
                transform: "translate(-50%, -50%)",
                pointerEvents: "none",
                zIndex: 5,
              }}
            >
              <motion.div
                initial={{ scale: 0.4, opacity: 0.85 }}
                animate={{ scale: 6, opacity: 0 }}
                transition={{ duration: 1.5, ease: [0.2, 0.6, 0.4, 1], delay }}
              >
                <div
                  style={{
                    width: 80,
                    height: 80,
                    borderRadius: "50%",
                    border: "1.5px solid rgba(147,197,253,0.55)",
                  }}
                />
              </motion.div>
            </div>
          ))}

        {/* ── TAP TO CONNECT BUTTON ── */}
        <div
          className="absolute z-30"
          style={{ left: "50%", top: "50%", transform: "translate(-50%, -50%)" }}
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: phase === "done" ? 0 : 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.75 }}
          >
            {/* Outer pulse ring 1 */}
            <div
              className="absolute"
              style={{ inset: -12, borderRadius: "50%", overflow: "visible" }}
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1], opacity: [0.42, 0.1, 0.42] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                style={{ width: "100%", height: "100%", borderRadius: "50%", border: "1.5px solid rgba(99,102,241,0.35)" }}
              />
            </div>
            {/* Outer pulse ring 2 */}
            <div
              className="absolute"
              style={{ inset: -26, borderRadius: "50%", overflow: "visible" }}
            >
              <motion.div
                animate={{ scale: [1, 1.14, 1], opacity: [0.18, 0.04, 0.18] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                style={{ width: "100%", height: "100%", borderRadius: "50%", border: "1px solid rgba(139,92,246,0.28)" }}
              />
            </div>

            {/* Glass button */}
            <motion.button
              onClick={handleConnect}
              disabled={phase !== "idle"}
              whileHover={{ scale: phase === "idle" ? 1.07 : 1 }}
              whileTap={{ scale: phase === "idle" ? 0.96 : 1 }}
              style={{
                width: 130,
                height: 130,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "rgba(255,255,255,0.38)",
                backdropFilter: "blur(22px)",
                WebkitBackdropFilter: "blur(22px)",
                border: "1px solid rgba(255,255,255,0.62)",
                boxShadow:
                  "0 8px 40px rgba(99,102,241,0.18), 0 2px 12px rgba(0,0,0,0.07), inset 0 1.5px 3px rgba(255,255,255,0.75)",
                position: "relative",
                overflow: "hidden",
                cursor: phase === "idle" ? "pointer" : "default",
                outline: "none",
              }}
            >
              {/* Glass shimmer overlay */}
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  borderRadius: "50%",
                  background:
                    "radial-gradient(circle at 34% 30%, rgba(255,255,255,0.65) 0%, transparent 55%)",
                  pointerEvents: "none",
                }}
              />
              <span
                style={{
                  fontSize: "0.83rem",
                  fontWeight: 500,
                  color: "#334155",
                  textAlign: "center",
                  lineHeight: 1.45,
                  position: "relative",
                  zIndex: 1,
                }}
              >
                {phase === "connecting" ? (
                  <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    style={{ color: "#6366f1" }}
                  >
                    Connecting…
                  </motion.span>
                ) : (
                  <>Tap to<br />Connect</>
                )}
              </span>
            </motion.button>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}