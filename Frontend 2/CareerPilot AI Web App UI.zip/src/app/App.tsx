import { useState } from "react";
import { AnimatePresence } from "motion/react";
import { IntroSection } from "./components/IntroSection";
import { PeterReveal } from "./components/PeterReveal";
import { MainProduct } from "./components/MainProduct";

type AppState = "intro" | "peter" | "main";

export default function App() {
  const [state, setState] = useState<AppState>("intro");

  return (
    <div className="w-full h-screen overflow-auto">
      <AnimatePresence mode="wait">
        {state === "intro" && (
          <IntroSection key="intro" onComplete={() => setState("peter")} />
        )}
        {state === "peter" && (
          <PeterReveal key="peter" onComplete={() => setState("main")} />
        )}
        {state === "main" && (
          <MainProduct key="main" />
        )}
      </AnimatePresence>
    </div>
  );
}